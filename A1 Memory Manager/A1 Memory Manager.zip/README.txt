Hi

I haven't tried compiling this in anything else than CLion on Windows,
with C++14, MinGW 5.0, CMake 3.7.2 and GDB 7.11.1. 
Dr. Tanzir said I didn't have to compile it in a Linux environment.
On my machine running for values 1,x works. But the bigger values cause errors. 
Still, as my first C++ project, I'm quite pleased.

There is no report. Although I will say one bottleneck is probably all the couts
since they are I/O operations.
